﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
///using System.Security.Policy;
using System.Web;
using System.Web.Mvc;
using MVC_Project.Models;
using Newtonsoft.Json;

namespace MVC_Project.Controllers
{
    public class PublisherMVCController : Controller
    {
        // GET: PublisherMVC
        string baseURL = "https://localhost:44386/api/";

        //public ActionResult Index()
        //{

        //    IEnumerable<Publisher> publisherList = null;
        //    using (var client = new HttpClient())
        //    {
        //        // Url of Webapi project
        //        client.BaseAddress = new Uri(baseURL);
        //        //HTTP GET
        //        var responseTask = client.GetAsync("Publishers");  // Stores is the WebApi controller name
        //                                                           // wait for task to complete
        //        responseTask.Wait();
        //        // retrieve the result
        //        var result = responseTask.Result;
        //        // check the status code for success
        //        if (result.IsSuccessStatusCode)
        //        {
        //            // read the result
        //            var readTask = result.Content.ReadAsAsync<IList<Publisher>>();
        //            readTask.Wait();
        //            // fill the list vairable created above with the returned result
        //            publisherList = readTask.Result;
        //        }
        //        else //web api sent error response 
        //        {
        //            publisherList = Enumerable.Empty<Publisher>();
        //            ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
        //        }
        //    }
        //    return View(publisherList);


        //return View();
        //}

        //public ActionResult Index(string name = null)
        //{
        //    IEnumerable<Publisher> publisherList = null;

        //    using (var client = new HttpClient())
        //    {
        //        client.BaseAddress = new Uri(baseURL);

        //        // If name is not null or empty, filter the publishers by name
        //        var apiUrl = string.IsNullOrEmpty(name) ? "Publishers" : $"publishers/pubname/{name}";

        //        // HTTP GET
        //        var responseTask = client.GetAsync(apiUrl);
        //        responseTask.Wait();

        //        var result = responseTask.Result;
        //        if (result.IsSuccessStatusCode)
        //        {
        //            var readTask = result.Content.ReadAsAsync<IList<Publisher>>();
        //            readTask.Wait();
        //            publisherList = readTask.Result;
        //        }
        //        else
        //        {
        //            publisherList = Enumerable.Empty<Publisher>();
        //            ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
        //        }
        //    }

        //    // Set the ViewBag property to the name parameter for use in the view
        //    ViewBag.SelectedName = name;

        //    return View(publisherList);
        //}


        public ActionResult Index(string searchType = null, string searchValue = null)
        {
            IEnumerable<Publisher> publisherList = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseURL);

                // Build the API URL based on the search type and value
                string apiUrl = "Publishers"; // Default URL for getting all publishers

                if (!string.IsNullOrEmpty(searchType) && !string.IsNullOrEmpty(searchValue))
                {
                    switch (searchType.ToLower())
                    {
                        case "name":
                            apiUrl = $"publishers/pubname/{searchValue}";
                            break;
                        case "id":
                            apiUrl = $"publishers/{searchValue}";
                            break;
                        case "city":
                            apiUrl = $"publishers/city/{searchValue}";
                            break;
                        case "state":
                            apiUrl = $"publishers/state/{searchValue}";
                            break;
                        case "country":
                            apiUrl = $"publishers/country/{searchValue}";
                            break;
                    }
                }

                // HTTP GET
                var responseTask = client.GetAsync(apiUrl);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Publisher>>();
                    readTask.Wait();
                    publisherList = readTask.Result;
                }
                else
                {
                    publisherList = Enumerable.Empty<Publisher>();
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            // Set ViewBag properties for use in the view
            ViewBag.SelectedValue = searchValue;
            ViewBag.SearchTypeName = searchType ?? "name"; // Default to "name"

            return View(publisherList);
        }




        // GET: PublisherMVC/Details/5
        public async Task<ActionResult> Details(string id)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseURL); 

                    HttpResponseMessage response = await client.GetAsync($"publishers/{id}");
                    response.EnsureSuccessStatusCode();

                    string responseData = await response.Content.ReadAsStringAsync();
                    var publisher = JsonConvert.DeserializeObject<Publisher>(responseData);

                    if (publisher == null)
                    {
                        return HttpNotFound();
                    }

                    return View(publisher);
                }
                catch (HttpRequestException ex)
                {
                    // Log the exception or handle as needed
                    ViewBag.ErrorMessage = $"Error fetching data: {ex.Message}";
                    return View("Error");
                }
                catch (Exception ex)
                {
                    // Log the exception or handle as needed
                    ViewBag.ErrorMessage = $"An unexpected error occurred: {ex.Message}";
                    return View("Error");
                }
            }
        }




        //GET: PublisherMVC/Create

        public ActionResult Create()
        {
            return View();
        }





        [HttpPost]
        public ActionResult Create(Publisher pubObj)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseURL);
                var postTask = client.PostAsJsonAsync<Publisher>("publishers/post", pubObj);
                postTask.Wait();
                var result = postTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    TempData["SuccessMessage"] = "Publisher created successfully!";
                    
                }
                else
                {
                    TempData["ErrorMessage"] = "Server Error. Please contact administrator.";
                }
            }
            
            return View(pubObj);
            
        }







        // GET: PublisherMVC/Edit/5
      
        public async Task<ActionResult> Edit(string id)
        {
            Publisher pubOBJ = null;

            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseURL); // Ensure baseURL is set correctly

                    HttpResponseMessage response = await client.GetAsync($"publishers/{id}" );
                    if (response.IsSuccessStatusCode)
                    {
                        pubOBJ = await response.Content.ReadAsAsync<Publisher>();
                    }
                    else
                    {
                        // Handle non-success status codes
                        ViewBag.ErrorMessage = $"Error: {response.ReasonPhrase}";
                        return View("Error");
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that occur during the HTTP request
                    ViewBag.ErrorMessage = $"An error occurred: {ex.Message}";
                    return View("Error");
                }
            }

            if (pubOBJ == null)
            {
                return HttpNotFound();
            }

         
            return View(pubOBJ);

        }

        // GET: TitlesMVC/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            Publisher publisher = null;

            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseURL); // Ensure baseURL is set correctly

                    HttpResponseMessage response = await client.GetAsync($"publishers/{id}");
                    if (response.IsSuccessStatusCode)
                    {
                        publisher = await response.Content.ReadAsAsync<Publisher>();
                    }
                    else
                    {
                        // Handle non-success status codes
                        ViewBag.ErrorMessage = $"Error: {response.ReasonPhrase}";
                        return View("Error");
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that occur during the HTTP request
                    ViewBag.ErrorMessage = $"An error occurred: {ex.Message}";
                    return View("Error");
                }
            }

            if (publisher == null)
            {
                return HttpNotFound();
            }

            return View(publisher);
        }


       
        // POST: TitlesMVC/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(baseURL); // Ensure baseURL is set correctly

                    HttpResponseMessage response = await client.DeleteAsync($"publishers/{id}");
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle non-success status codes
                        ViewBag.ErrorMessage = $"Error: {response.ReasonPhrase}";
                        return View("Error");
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that occur during the HTTP request
                    ViewBag.ErrorMessage = $"An error occurred: {ex.Message}";
                    return View("Error");
                }
            }
        }


        // POST: PublisherMVC/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(string id,Publisher publisher)
        {
            if (!ModelState.IsValid)
            {
                return View(publisher);
            }

            using (var client = new HttpClient())
            {
                try
                {
                    publisher.pub_id =id;
                    client.BaseAddress = new Uri(baseURL); // Ensure baseURL is set correctly

                    HttpResponseMessage response = await client.PutAsJsonAsync($"publishers/"+publisher.pub_id,publisher);
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.ErrorMessage = $"Error: {response.ReasonPhrase}";
                        return View("Error");
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.ErrorMessage = $"An error occurred: {ex.Message}";
                    return View("Error");
                }
            }
        }

        
    }
}
